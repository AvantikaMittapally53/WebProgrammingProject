@extends('layouts.app')

@section('content')
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
    .row.mt-5.context .card-body {
    background: #f7f7f7;
}

.card.mt-2 {
    border: none;
}

ul.pagination {
    justify-content: center;
}
button.btn.btn-lg.btn-success {
    border-radius: 30px;
    line-height: normal;
    text-transform: uppercase;
    font-size: 16px;
}

.container.mt-5 h3 {
    text-align: center;
    margin-bottom: 20px;
    font-weight: 400;
}

.d-flex .form-control.form-control-lg.form-control-borderless {
    border: 1px solid #ddd;
    border-radius: 30px;
    font-size: 16px;
}
.d-flex :where(.col,.col-auto) {
    padding: 0;
}
</style>   
<div class="container">
    <br/>
	<div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8">
                            <div class="top-heading"><h2>ETD Search</h2></div>
                            <form class="card card-sm" method="GET" action="/search">
                            @csrf

                                <div class="card-body row no-gutters align-items-center">
                                    <label>Searchtext:</label>
                                    <!-- <div class="col-auto">
                                        <i class="fas fa-search h4 text-body"></i>
                                    </div> -->
                                    <!--end of col-->
                                   <div class="d-flex gap-2"> <div class="col">
                                        <input  class="form-control form-control-lg form-control-borderless" type="search" placeholder="Search topics or keywords" id="q" name="q" value={{ request()->get('q', '') }} >
                                    </div>
                                    <!--end of col-->
                                    <div class="col-auto">
                                        <button class="btn btn-lg btn-success" type="submit">Search</button>
                                    </div>
                                    <!--end of col-->
                                   </div>
                                </div>
                            </form>
                        </div>
                        <!--end of col-->
                    </div>
</div>




    <div class="container mt-5">

    <!-- <h1 class="text-center">All the documents</h1> -->
    @if (request()->get('q'))
    <h3> Found About {{$documents->total()}}  Results for <b>machine learning</b></h3>
    @else
    <h3> Found About {{$documents->total()}}  Results for <b>machine learning</b></h3>
 
 @endif
 @if (request()->get('q'))
{!! $documents->appends($_GET)->links("pagination::bootstrap-4") !!}

@else
{!! $documents->appends($_GET)->links("pagination::bootstrap-4") !!}
@endif
    <div class="row mt-5 context">
    @foreach($documents as $document)
            <div class="col-lg-12">
                <div class="card mt-2">
                    <div class="card-body">
                        <a href="/search/{{$document->id}}" ><h5 class="card-title">{{$document->title}}</h5></a>
                        <p class="card-text">{{$document->author}}</p>
                        <div class="description">
                            <div class="short-decscription" style="height:100%;max-height:100px;overflow: hidden;">
                            <p>{{$document->text_data}}</p>
                            </div>
                            <a href="javascript:void(0);" class="read_more">read more....</a>
                            <a href="javascript:void(0);" class="read_less" style="display:none;">read less</a>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>



<script src="https://cdnjs.cloudflare.com/ajax/libs/mark.js/8.11.1/mark.min.js" integrity="sha512-5CYOlHXGh6QpOFA/TeTylKLWfB3ftPsde7AnmhuitiTX4K5SqCLBeKro6sPS8ilsz1Q4NRx3v8Ko2IBiszzdww==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script>
jQuery(document).ready(function(){
    jQuery('.description a.read_more').on("click",function(){
   jQuery(this).parent().find(".short-decscription").css('max-height','100%');
   jQuery(this).hide();
   jQuery(this).parent().find('.read_less').show();
});
jQuery('.description a.read_less').on("click",function(){
    jQuery(this).parent().find(".short-decscription").css('max-height','100px');
   jQuery(this).hide();
   jQuery(this).parent().find('.read_more').show();
});
})
var instance = new Mark(document.querySelector(".context"));
instance.mark("{{ request()->get('q', '') }}");
</script>

@endsection
